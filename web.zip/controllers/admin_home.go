package controllers

import "web/models"

type AdminHomeController struct {
	JudgeController
	P1 	 string
	P2 	 string
	P3 	 string
	P4	 string
	P5	 string
	News string
}

type Picture struct {
	Url	string
}
func (c *AdminHomeController) Get() {
	c.Data["adminName"] = c.Loginuser
	c.TplName = "admin_home.html"
}

func (c *AdminHomeController) Post() {
	id1   := c.GetString("slideshow_1")
	id2   := c.GetString("slideshow_2")
	id3   := c.GetString("slideshow_3")
	id4   := c.GetString("slideshow_4")
	id5   := c.GetString("slideshow_5")
	c.News = c.GetString("news")

	//根据管理员输入的书籍id提取出对应书籍的封面
	maps1 := models.ShowPictureOnHomeByAdmin(id1)
	maps2 := models.ShowPictureOnHomeByAdmin(id2)
	maps3 := models.ShowPictureOnHomeByAdmin(id3)
	maps4 := models.ShowPictureOnHomeByAdmin(id4)
	maps5 := models.ShowPictureOnHomeByAdmin(id5)

	var picture1 [1]Picture
	var picture2 [1]Picture
	var picture3 [1]Picture
	var picture4 [1]Picture
	var picture5 [1]Picture

	i1 := 0
	for _,n := range maps1{
		picture1[i1].Url		= n["novel_pic"].(string)
		c.P1 					= n["novel_pic"].(string)
		i1++
	}
	i2 := 0
	for _,n := range maps2{
		picture2[i2].Url		= n["novel_pic"].(string)
		c.P2 					= n["novel_pic"].(string)
		i2++
	}
	i3 := 0
	for _,n := range maps3{
		picture3[i3].Url		= n["novel_pic"].(string)
		c.P3 					= n["novel_pic"].(string)
		i3++
	}
	i4 := 0
	for _,n := range maps4{
		picture4[i4].Url		= n["novel_pic"].(string)
		c.P4 					= n["novel_pic"].(string)
		i4++
	}
	i5 := 0
	for _,n := range maps5{
		picture5[i5].Url		= n["novel_pic"].(string)
		c.P5 					= n["novel_pic"].(string)
		i5++
	}
	var maps []map[string]interface{}
	map1 := map[string]interface{}{"url": picture1}
	map2 := map[string]interface{}{"url": picture2}
	map3 := map[string]interface{}{"url": picture3}
	map4 := map[string]interface{}{"url": picture4}
	map5 := map[string]interface{}{"url": picture5}
	maps = append(maps,map1,map2,map3,map4,map5)

	c.Data["json"] = map[string]interface{}{"url":maps}
	c.ServeJSON()
}