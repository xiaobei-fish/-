package controllers

type HomeController struct {
	//beego.Controller
	JudgeController
	AdminHomeController
}

func (c *HomeController) Get() {
	c.Data["P1"] = c.P1
	c.Data["P2"] = c.P2
	c.Data["P3"] = c.P3
	c.Data["P4"] = c.P4
	c.Data["P5"] = c.P5
	c.Data["news"] = c.News
	c.Data["Username"] = c.Loginuser
	c.TplName = "home.html"
}
