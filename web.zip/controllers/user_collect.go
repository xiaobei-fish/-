package controllers

import (
	"strconv"
	"web/models"
)

type CollectBookController struct {
	JudgeController
}

func (c *CollectBookController) Get() {
	c.TplName = "search.html"
}

func (c *CollectBookController) Post() {

	//得到要收藏书籍的信息
	ID 			 := c.GetString("Id")
	name 		 := c.GetString("Name")
	genre 		 := c.GetString("Genres")
	introduction := c.GetString("Introduction")
	writer 		 := c.GetString("Writer")
	picture 	 := c.GetString("Picture")
	state 		 := c.GetString("State")

	Id, _ := strconv.Atoi(ID)
	username := c.Loginuser
	//实例化model，将它出入到数据库中
	m := models.Novel{Id: Id,Name:name,Genres:genre,Introduction:introduction,Writer:writer,Picture:picture,State:state}
	_, err := models.CollectNovel(m,username.(string))

	//返回数据给浏览器
	var response map[string]interface{}
	if err == nil {
		//无误
		response = map[string]interface{}{"code": 1, "message": "ok"}   //用code给前端来判断收藏成不成功
	} else {
		response = map[string]interface{}{"code": 0, "message": "error"}
	}
	c.Data["json"] = response
	c.ServeJSON()
}