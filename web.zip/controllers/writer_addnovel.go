package controllers

import (
	"web/models"
)

type AddNovelController struct {
	JudgeController
}

func (c *AddNovelController) Get() {
	c.TplName = "writer.html"
}

func (c *AddNovelController) Post() {

	//获取浏览器传输的数据，通过表单的name属性获取值
	name 		 := c.GetString("name")
	genre 		 := c.GetString("genre")
	introduction := c.GetString("introduction")
	writer 		 := c.GetString("writer")
	state 		 := c.GetString("state")

	//存入数据库中
	novel := models.NovelInfo{Novel_name:name, Novel_introduction:introduction, Novel_state:state, Novel_writer:writer, Novel_genre:genre}
	_, err := models.AddArticle(novel)

	//返回数据给浏览器
	var response map[string]interface{}

	if err == nil {
		//无误
		response = map[string]interface{}{"code": 1, "message": "ok"}//根据code的值判断是否增加成功
	} else {
		response = map[string]interface{}{"code": 0, "message": "error"}
	}

	c.Data["json"] = response
	c.ServeJSON()
}
