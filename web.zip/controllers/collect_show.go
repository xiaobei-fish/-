package controllers

type PageController struct {
	JudgeController
}

func (c *PageController)Get()  {
	c.Data["Username"] = c.Loginuser
	c.TplName = "collect.html"
}
