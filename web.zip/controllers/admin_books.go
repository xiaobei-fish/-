package controllers

type AdminBooksController struct {
	JudgeController
}

func (c *AdminBooksController) Get() {
	c.Data["adminName"] = c.Loginuser
	c.TplName = "admin_books.html"
}
