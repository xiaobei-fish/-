package controllers

type SelfhomeController struct {
	JudgeController
}

func (c *SelfhomeController) Get() {
	c.Data["Username"] = c.Loginuser
	c.TplName = "selfhome.html"
}