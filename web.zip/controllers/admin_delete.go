package controllers

import (
	"fmt"
	"log"
	"web/models"
)


type AdminDeleteController struct {
	JudgeController
}

//点击删除后重定向到管理员书籍页
func (c *AdminDeleteController) Get() {
	novelID, _ := c.GetInt("id")//得到小说块小说对应的id

	fmt.Println("删除 id:", novelID)

	_, err := models.DeleteNovel(novelID)
	if err != nil {
		log.Println(err)
	}
	c.Redirect("/admin/books", 302)
}

