package controllers

type ResultController struct {
	JudgeController
}

func (c *ResultController) Get()  {
	keyWords := c.GetString("keyWords")
	c.Data["Username"] = c.Loginuser
	c.Data["keyWords"] = keyWords
	c.TplName = "search.html"
}
