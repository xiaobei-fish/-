package controllers

import (
	"fmt"
	"strconv"
	"web/models"
)

type SearchController struct {
	JudgeController
}

func (c *SearchController) Get() {
	c.Data["Username"] = c.Loginuser
	keyWords := c.GetString("keyWords")
	pageIndex := c.GetString("page")//获取页面的page参数值,前端会发送,默认为1
	page,_ := strconv.Atoi(pageIndex)	 //转化成Int类型用于函数
	fmt.Println("pageIndex:",page)
	//page=1
	if keyWords == "" {
		empty, num := models.FindNovelWithKeyWordsOnEmpty(page)
		var novel [8]Novel
		i := 0
		for _,n := range empty{
			novel[i].Id				= n["id"].(string)
			novel[i].Name 			= n["novel_name"].(string)
			novel[i].Picture 		= n["novel_pic"].(string)
			novel[i].Writer 		= n["novel_writer"].(string)
			novel[i].Introduction 	= n["novel_introduction"].(string)
			novel[i].Genres 		= n["novel_genre"].(string)
			novel[i].State 			= n["novel_state"].(string)
			i++
		}
		c.Data["json"] 	   = map[string]interface{}{"novel":novel , "num": num, "code": 0}
		c.ServeJSON()
	}else {
		result1, num1 := models.FindNovelWithKeyWordsOnName(keyWords, page)
		result2, num2 := models.FindNovelWithKeyWordsOnGenre(keyWords, page)
		result3, num3 := models.FindNovelWithKeyWordsOnWriter(keyWords, page)
		result4, num4 := models.FindNovelWithKeyWordsOnState(keyWords, page)

		if num1 == 0 && num2 == 0 && num3 == 0 && num4 == 0 {
			c.Data["json"] = map[string]interface{}{"code": 1, "num": 0}
			c.ServeJSON()
		}
		//返回所有匹配结果
			var maps []map[string]interface{}
			var novel1 [8]Novel
			i := 0
			for _, n := range result1 {
				novel1[i].Id = n["id"].(string)
				novel1[i].Name = n["novel_name"].(string)
				novel1[i].Picture = n["novel_pic"].(string)
				novel1[i].Writer = n["novel_writer"].(string)
				novel1[i].Introduction = n["novel_introduction"].(string)
				novel1[i].Genres = n["novel_genre"].(string)
				novel1[i].State = n["novel_state"].(string)
				i++
			}
			map1 := map[string]interface{}{"novel": novel1}
			fmt.Println("1:",map1)

			var novel2 [8]Novel
			i2 := 0
			for _, n := range result2 {
				novel2[i2].Id = n["id"].(string)
				novel2[i2].Name = n["novel_name"].(string)
				novel2[i2].Picture = n["novel_pic"].(string)
				novel2[i2].Writer = n["novel_writer"].(string)
				novel2[i2].Introduction = n["novel_introduction"].(string)
				novel2[i2].Genres = n["novel_genre"].(string)
				novel2[i2].State = n["novel_state"].(string)
				i2++
			}
			map2 := map[string]interface{}{"novel": novel2}
			fmt.Println("2:",map2)

			var novel3 [8]Novel
			i3 := 0
			for _, n := range result3 {
				novel3[i3].Id = n["id"].(string)
				novel3[i3].Name = n["novel_name"].(string)
				novel3[i3].Picture = n["novel_pic"].(string)
				novel3[i3].Writer = n["novel_writer"].(string)
				novel3[i3].Introduction = n["novel_introduction"].(string)
				novel3[i3].Genres = n["novel_genre"].(string)
				novel3[i3].State = n["novel_state"].(string)
				i3++
			}
			map3 := map[string]interface{}{"novel": novel3}
			fmt.Println("3:",map3)

			var novel4 [8]Novel
			i4 := 0
			for _, n := range result4 {
				novel4[i4].Id = n["id"].(string)
				novel4[i4].Name = n["novel_name"].(string)
				novel4[i4].Picture = n["novel_pic"].(string)
				novel4[i4].Writer = n["novel_writer"].(string)
				novel4[i4].Introduction = n["novel_introduction"].(string)
				novel4[i4].Genres = n["novel_genre"].(string)
				novel4[i4].State = n["novel_state"].(string)
				i4++
			}
			map4 := map[string]interface{}{"novel": novel4}
			fmt.Println("4:",map4)
			maps = append(maps,map1,map2,map3,map4)
			fmt.Println("///",maps)
			c.Data["json"] = map[string]interface{}{"novel": maps, "num": num1+num2+num3+num4, "code": 0}
			c.ServeJSON()

		//c.TplName = "search.html"
	}
}

/*func (c *SearchController) Post(){

}*/
