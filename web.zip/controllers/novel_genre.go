package controllers

import (
	"fmt"
	"web/models"
)

type GenreController struct {
	JudgeController
}

func (c *GenreController) Get() {
	genre := models.QueryNovelWithParam("novel_genre")

	fmt.Println(models.HandleGenreListData(genre))

	c.Data["Genre"] = models.HandleGenreListData(genre)

	c.TplName = "selfhome.html"
}
