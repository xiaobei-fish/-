package controllers

type WriterController struct {
	JudgeController
}

func (c *WriterController) Get() {
	c.Data["Username"] = c.Loginuser
	c.TplName = "writer.html"
}
