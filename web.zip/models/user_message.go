package models

import (
	"fmt"
	"github.com/astaxie/beego"
	"github.com/astaxie/beego/orm"
	"web/utils"
)

type User struct {
	Id         string
	Username   string
	Password   string
	Genre	   int // 0 普通用户， 1管理员
	Status     int // 0 正常状态， 1删除
	Createtime int64
}


//插入
func InsertUser(user User) (int64, error) {
	return utils.ModifyDB("insert into users(username,password,genre,status,createtime) values (?,?,?,?,?)",
		user.Username, user.Password, user.Genre, user.Status, user.Createtime)
}

//按条件查询
func QueryUserWightCon(con string) int {
	sql := fmt.Sprintf("select id from users %s", con)
	fmt.Println(sql)
	row := utils.QueryRowDB(sql)
	id := 0
	row.Scan(&id)
	return id
}

//根据用户名查询id
func QueryUserWithUsername(username string) int {
	sql := fmt.Sprintf("where username='%s'", username)
	return QueryUserWightCon(sql)
}

//根据用户名和密码，查询id
func QueryUserWithParam(username, password string) int {
	sql := fmt.Sprintf("where username='%s' and password='%s'", username, password)
	return QueryUserWightCon(sql)
}

//查询用户的条数
func QueryUserRowNum() int {
	row := utils.QueryRowDB("select count(id) from users")
	num := 0
	row.Scan(&num)
	return num
}

//根据页码查询用户并返回数据以便展示
func FindUserWithPage(page int) []orm.Params {
	orm.Debug = true
	//从配置文件中获取每页展示的用户数量
	num, _ := beego.AppConfig.Int("userListPageNum")
	page--
	sql := fmt.Sprintf("limit %d,%d", page*num, num)
	//fmt.Println("sql:::::::::::",sql)
	sql = "select id,username from users " + sql
	//fmt.Println("sql:::::::::::",sql)

	var Users []orm.Params
	fmt.Println("var是正常的")
	i, e := db.Raw(sql).Values(&Users)
	fmt.Println("输出是:",i)
	if e != nil {
		fmt.Println("Raw出错")
	}

	return Users
}