package models



func HandleGenreListData(genres []string) map[string]int {
	var genresMap = make(map[string]int)
		for _, value := range genres {
			genresMap[value]++
		}
	return genresMap
}
