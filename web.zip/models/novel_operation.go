package models

import (
	"fmt"
	"github.com/astaxie/beego"
	"github.com/astaxie/beego/orm"
	"log"
	"web/utils"
)

type Novel struct {
	Id         		int
	Name     		string
	Genres       	string
	Introduction    string
	Writer     		string
	Picture			string
	State			string
}

//用户收藏小说
func CollectNovel(novel Novel,username string) (int64, error) {
	i, err := insertNovel(novel,username)
	SetNovelRowsNum()
	return i, err
}

//储存收藏的小说id和用户名
func insertNovel(novel Novel,username string) (int64, error) {
	return utils.ModifyDB("insert into user_collect(novel_ids,username,novel_name,novel_genre,novel_introduction,novel_state,novel_writer,novel_pic)" +
		"values(?,?,?,?,?,?,?,?)",novel.Id,username,novel.Name,novel.Genres,novel.Introduction,novel.State,novel.Writer,novel.Picture)
}


//根据页码查询小说并返回数据以便展示
func FindNovelWithPage(page int) []orm.Params {
	orm.Debug = true
	//从配置文件中获取每页展示的小说数量
	num, _ := beego.AppConfig.Int("novelListPageNum")
	page--
	//fmt.Println("page::::::::::", page)
	//fmt.Println("num:::::::::::", num)
	sql := fmt.Sprintf("limit %d,%d", page*num, num)
	//fmt.Println("sql:::::::::::",sql)
	sql = "select id,novel_name,novel_genre,novel_introduction,novel_state,novel_writer,novel_pic from novel_info " + sql
	//fmt.Println("sql:::::::::::",sql)

	var Novel []orm.Params
	fmt.Println("var是正常的")
	i, e := db.Raw(sql).Values(&Novel)
	fmt.Println("输出是:",i)
	if e != nil {
		fmt.Println("Raw出错")
	}
	//fmt.Println("Novel:",Novel)

	return Novel
}

//空关键字返回全部书籍
func FindNovelWithKeyWordsOnEmpty(page int) ([]orm.Params,int64) {
	orm.Debug = true
	num, _ := beego.AppConfig.Int("novelListPageNum")
	page--
	Limit := fmt.Sprintf("limit %d,%d", page*num, num)

	var Novel []orm.Params

	sql := "select id,novel_name,novel_genre,novel_introduction,novel_state,novel_writer,novel_pic from novel_info "
	sql  = sql + Limit
	i, e := db.Raw(sql).Values(&Novel)
	fmt.Println("输出是:",i)
	if e != nil {
		fmt.Println("Raw出错")
	}
	//fmt.Println("Novel:",Novel)

	return Novel, i
}

//根据关键字搜索小说名以得到检索
func FindNovelWithKeyWordsOnName(keyWords string, page int) ([]orm.Params,int64) {
	orm.Debug = true
	var Novel []orm.Params
	num, _ := beego.AppConfig.Int("novelListPageNum")
	page--
	Limit := fmt.Sprintf("limit %d,%d", page*num, num)

	sql := "select id,novel_name,novel_genre,novel_introduction,novel_state,novel_writer,novel_pic from novel_info where novel_name like "
	keyWords = "'%" + keyWords + "%' "
	sql = sql + keyWords + Limit

	i, e := db.Raw(sql).Values(&Novel)
	fmt.Println("输出是:",i)
	if e != nil {
		fmt.Println("Raw出错")
	}
	//fmt.Println("Novel:",Novel)

	return Novel, i
}

//根据关键字搜索小说种类以得到检索
func FindNovelWithKeyWordsOnGenre(keyWords string, page int) ([]orm.Params,int64) {
	orm.Debug = true
	var Novel []orm.Params
	num, _ := beego.AppConfig.Int("novelListPageNum")
	page--
	Limit := fmt.Sprintf("limit %d,%d", page*num, num)

	sql := "select id,novel_name,novel_genre,novel_introduction,novel_state,novel_writer,novel_pic from novel_info where novel_genre like "
	keyWords = "'%" + keyWords + "%' "
	sql = sql + keyWords + Limit

	i, e := db.Raw(sql).Values(&Novel)
	fmt.Println("输出是:",i)
	if e != nil {
		fmt.Println("Raw出错")
	}
	//fmt.Println("Novel:",Novel)

	return Novel, i
}

//根据关键字搜索小说作者以得到检索
func FindNovelWithKeyWordsOnWriter(keyWords string, page int) ([]orm.Params,int64) {
	orm.Debug = true
	var Novel []orm.Params
	num, _ := beego.AppConfig.Int("novelListPageNum")
	page--
	Limit := fmt.Sprintf("limit %d,%d", page*num, num)

	sql := "select id,novel_name,novel_genre,novel_introduction,novel_state,novel_writer,novel_pic from novel_info where novel_writer like "
	keyWords = "'%" + keyWords + "%' "
	sql = sql + keyWords + Limit

	i, e := db.Raw(sql).Values(&Novel)
	fmt.Println("输出是:",i)
	if e != nil {
		fmt.Println("Raw出错")
	}
	//fmt.Println("Novel:",Novel)

	return Novel, i
}

//根据关键字搜索小说状态以得到检索
func FindNovelWithKeyWordsOnState(keyWords string, page int) ([]orm.Params,int64) {
	orm.Debug = true
	var Novel []orm.Params
	num, _ := beego.AppConfig.Int("novelListPageNum")
	page--
	Limit := fmt.Sprintf("limit %d,%d", page*num, num)

	sql := "select id,novel_name,novel_genre,novel_introduction,novel_state,novel_writer,novel_pic from novel_info where novel_state like "
	keyWords = "'%" + keyWords + "%' "
	sql = sql + keyWords + Limit

	i, e := db.Raw(sql).Values(&Novel)
	fmt.Println("输出是:",i)
	if e != nil {
		fmt.Println("Raw出错")
	}
	//fmt.Println("Novel:",Novel)

	return Novel, i
}

//根据收藏的Id来返回收藏书籍的数据
func FindNovelWithUsername(page int, username string) []orm.Params {
	orm.Debug = true
	//从配置文件中获取每页展示的小说数量
	num, _ := beego.AppConfig.Int("novelListPageNum")
	page--
	//fmt.Println("page::::::::::", page)
	//fmt.Println("num:::::::::::", num)
	name := "where username='" + username + "' "
	sql := fmt.Sprintf("limit %d,%d", page*num, num)
	//fmt.Println("sql:::::::::::",sql)
	sql = "select id,novel_name,novel_genre,novel_introduction,novel_state,novel_writer,novel_pic from user_collect " + name + sql
	//fmt.Println("sql:::::::::::",sql)

	var Novel []orm.Params
	fmt.Println("var是正常的")
	i, e := db.Raw(sql).Values(&Novel)
	fmt.Println("输出是:",i)
	if e != nil {
		fmt.Println("Raw出错")
	}
	//fmt.Println("Novel:",Novel)
	return Novel
}

//存储表的行数，只有自己可以更改，当收藏夹中小说新增或者删除时需要更新这个值
var novelcileRowsNum = 0

//只有首次获取行数的时候采取统计表里的行数
func GetNovelRowsNum() int {
	if novelcileRowsNum == 0 {
		novelcileRowsNum = QueryNovelRowNum()
	}
	return novelcileRowsNum
}

//查询文章的总条数
func QueryNovelRowNum() int {
	row := utils.QueryRowDB("select count(id) from novel_info")
	num := 0
	row.Scan(&num)
	return num
}

//设置页数
func SetNovelRowsNum(){
	novelcileRowsNum = QueryNovelRowNum()
}

//查询标签，返回一个字段的列表
func QueryNovelWithParam(param string) []string {
	rows, err := utils.QueryDB(fmt.Sprintf("select %s from novel_info", param))
	if err != nil {
		log.Println(err)
	}
	var paramList []string
	for rows.Next() {
		arg := ""
		rows.Scan(&arg)
		paramList = append(paramList, arg)
	}
	return paramList
}

//插入新小说
func AddArticle(novel NovelInfo) (int64, error) {
	i, err := insertArticle(novel)
	return i, err
}
func insertArticle(novel NovelInfo) (int64, error) {
	return utils.ModifyDB("insert into novel_info(novel_name,novel_genre,novel_introduction,novel_state,novel_writer) values(?,?,?,?,?)",
		novel.Novel_name,novel.Novel_genre,novel.Novel_introduction,novel.Novel_state,novel.Novel_writer)
}