package models

import (
	"fmt"
	"github.com/astaxie/beego/orm"
	"web/utils"
)

func ShowPictureOnHomeByAdmin(id string) []orm.Params{
	sql := "select novel_pic from novel_info where id="
	find := "'" + id + "'"
	sql = sql + find

	var Picture []orm.Params

	fmt.Println("var是正常的")
	i, e := db.Raw(sql).Values(&Picture)
	fmt.Println("输出是:",i)
	if e != nil {
		fmt.Println("Raw出错")
	}
	fmt.Println("Picture:",Picture)

	return Picture
}

func DeleteNovel(novelID int) (int64, error) {

	//删除文章
	i, err := DeleteNovelWithId(novelID)

	//计算小说总页码数,看看会不会删除导致页码减少
	SetNovelRowsNum()
	return i, err
}

func DeleteNovelWithId(ID int) (int64, error) {
	return utils.ModifyDB("delete from novel_info where id=?", ID)
}